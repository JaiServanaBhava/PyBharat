from setuptools import setup, find_packages

setup(
    name="pyindia",
    version="1.0.0",
    description="Comprehensive Indian information library",
    author="Jai",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
)
