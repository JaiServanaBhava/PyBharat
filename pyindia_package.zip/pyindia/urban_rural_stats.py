# urban_rural_stats.py

def sample_function():
    return 'urban_rural_stats module loaded successfully.'
