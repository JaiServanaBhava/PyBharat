# travel_food.py

def sample_function():
    return 'travel_food module loaded successfully.'
