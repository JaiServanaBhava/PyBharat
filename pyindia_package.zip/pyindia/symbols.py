# symbols.py

def sample_function():
    return 'symbols module loaded successfully.'
