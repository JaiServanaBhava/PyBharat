# ecommerce_data.py

def sample_function():
    return 'ecommerce_data module loaded successfully.'
