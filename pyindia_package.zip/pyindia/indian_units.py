# indian_units.py

def sample_function():
    return 'indian_units module loaded successfully.'
