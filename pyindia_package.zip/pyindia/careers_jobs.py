# careers_jobs.py

def sample_function():
    return 'careers_jobs module loaded successfully.'
