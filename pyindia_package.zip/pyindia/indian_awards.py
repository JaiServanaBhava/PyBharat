# indian_awards.py

def sample_function():
    return 'indian_awards module loaded successfully.'
