# sports_cricket.py

def sample_function():
    return 'sports_cricket module loaded successfully.'
