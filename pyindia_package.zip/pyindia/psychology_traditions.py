# psychology_traditions.py

def sample_function():
    return 'psychology_traditions module loaded successfully.'
