# healthcare_info.py

def sample_function():
    return 'healthcare_info module loaded successfully.'
