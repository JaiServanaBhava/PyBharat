# indian_trivia.py

def sample_function():
    return 'indian_trivia module loaded successfully.'
