# indian_companies.py

def sample_function():
    return 'indian_companies module loaded successfully.'
