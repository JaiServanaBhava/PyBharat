# education_stats.py

def sample_function():
    return 'education_stats module loaded successfully.'
