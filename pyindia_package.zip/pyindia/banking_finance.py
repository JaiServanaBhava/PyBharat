# banking_finance.py

def sample_function():
    return 'banking_finance module loaded successfully.'
