# travel_routes.py

def sample_function():
    return 'travel_routes module loaded successfully.'
