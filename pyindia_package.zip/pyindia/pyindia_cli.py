# pyindia_cli.py

def sample_function():
    return 'pyindia_cli module loaded successfully.'
