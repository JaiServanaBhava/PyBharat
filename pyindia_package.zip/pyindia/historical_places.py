# historical_places.py

def sample_function():
    return 'historical_places module loaded successfully.'
