# indian_schemes_benefits.py

def sample_function():
    return 'indian_schemes_benefits module loaded successfully.'
