# defense.py

def sample_function():
    return 'defense module loaded successfully.'
