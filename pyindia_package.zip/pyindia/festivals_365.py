# festivals_365.py

def sample_function():
    return 'festivals_365 module loaded successfully.'
