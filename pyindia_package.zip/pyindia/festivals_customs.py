# festivals_customs.py

def sample_function():
    return 'festivals_customs module loaded successfully.'
