# state_budget_data.py

def sample_function():
    return 'state_budget_data module loaded successfully.'
