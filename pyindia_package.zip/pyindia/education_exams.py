# education_exams.py

def sample_function():
    return 'education_exams module loaded successfully.'
