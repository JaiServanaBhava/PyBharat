# geography.py

def sample_function():
    return 'geography module loaded successfully.'
