# rivers_dams.py

def sample_function():
    return 'rivers_dams module loaded successfully.'
