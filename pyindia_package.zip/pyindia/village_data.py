# village_data.py

def sample_function():
    return 'village_data module loaded successfully.'
