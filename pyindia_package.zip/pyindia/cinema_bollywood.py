# cinema_bollywood.py

def sample_function():
    return 'cinema_bollywood module loaded successfully.'
