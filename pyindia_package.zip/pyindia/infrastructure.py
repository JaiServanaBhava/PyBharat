# infrastructure.py

def sample_function():
    return 'infrastructure module loaded successfully.'
