# astro_space.py

def sample_function():
    return 'astro_space module loaded successfully.'
