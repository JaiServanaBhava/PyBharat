# legislature_data.py

def sample_function():
    return 'legislature_data module loaded successfully.'
