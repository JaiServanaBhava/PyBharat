# temples_festivals.py

def sample_function():
    return 'temples_festivals module loaded successfully.'
