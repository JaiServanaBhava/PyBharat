# weather_climate.py

def sample_function():
    return 'weather_climate module loaded successfully.'
