# states.py

def sample_function():
    return 'states module loaded successfully.'
