# music_instruments.py

def sample_function():
    return 'music_instruments module loaded successfully.'
