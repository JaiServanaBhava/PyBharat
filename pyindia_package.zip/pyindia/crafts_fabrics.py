# crafts_fabrics.py

def sample_function():
    return 'crafts_fabrics module loaded successfully.'
