# ayurveda_yoga.py

def sample_function():
    return 'ayurveda_yoga module loaded successfully.'
