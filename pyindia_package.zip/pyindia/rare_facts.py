# rare_facts.py

def sample_function():
    return 'rare_facts module loaded successfully.'
