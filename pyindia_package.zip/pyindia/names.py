# names.py

def sample_function():
    return 'names module loaded successfully.'
