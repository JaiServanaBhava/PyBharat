# utility.py

def sample_function():
    return 'utility module loaded successfully.'
