# emergency_contacts.py

def sample_function():
    return 'emergency_contacts module loaded successfully.'
