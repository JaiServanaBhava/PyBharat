# states_and_neighbors.py

def sample_function():
    return 'states_and_neighbors module loaded successfully.'
